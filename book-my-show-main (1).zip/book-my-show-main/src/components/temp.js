import React from "react";

function Temp() {
  return <h1>This is a temp component</h1>
}

export default Temp;
